package outrouter;

import java.util.*;

public class Tim1
{
	public long calculateTime()
		{
			Date d=new Date();
			return d.getTime();
		}
}
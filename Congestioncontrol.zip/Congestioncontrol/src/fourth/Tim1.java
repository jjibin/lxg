package fourth;

import java.util.*;

class Tim1
{
	public long calculateTime()
	{
		Date d=new Date();
		return d.getTime();
	}

}
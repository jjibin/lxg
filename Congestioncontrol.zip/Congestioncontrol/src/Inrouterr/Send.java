package Inrouterr;

import Inrouterr.Inrouter.B;
import Inrouterr.Inrouter.In_Frame;
import outrouter.Tim;
import outrouter.Tim1;
import java.util.*;
import java.net.*;
import java.io.*;

public class Send extends TimerTask
{
	Tim ti;
	Tim1 t1;
	Thread t;
	InetAddress i;
	In_Frame Fra2;
        Inrouter inr1;
	String str="";
	public Send(In_Frame Fra1)
	{
		Fra2=Fra1;
		ti=new Tim();
		t1=new Tim1();
		try
		{
			i=InetAddress.getLocalHost();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}
	public void run()
	{
		if(!Fra2.msg.isEmpty())
		{
			try
			{
				try
				{
					Thread.sleep(Fra2.tot*Fra2.msg.size());
				}
				catch(Exception e){}
				Socket soc1=new Socket("localhost",7799);
			ObjectOutputStream oos=new ObjectOutputStream(soc1.getOutputStream());
				str=i.getHostName()+"~"+"localhost"+"|"+ti.calculateTime()+"|f";
				for(int i=0;i<Fra2.len.size();i++)
				{
					str+="|"+Fra2.sour.get(i)+"~"+Fra2.des.get(i)+"~"+Fra2.len.get(i);
				}
				str+="|"+t1.calculateTime();
				inr1.Ing_data.append("---------------------------------------------------------------\n");
				inr1.Ing_data.append(str);
       			        inr1.Ing_data.append("\n"+"---------------------------------------------------------------\n");
				oos.writeObject(str);
				B b=new B(Fra2);

			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
		else
		{
			try
			{
				Fra2.l=t1.calculateTime();
				Socket soc1=new Socket("localhost",7799);
				ObjectOutputStream oos=new ObjectOutputStream(soc1.getOutputStream());
				str=i.getHostName()+"~"+"localhost"+"|"+ti.calculateTime()+"|"+"There is no message";
				inr1.Ing_data.append("---------------------------------------------------------------\n");
				inr1.Ing_data.append(str);
				inr1.Ing_data.append("\n"+"---------------------------------------------------------------\n");
				oos.writeObject(str);
			}
			catch(Exception e)
			{
				e.printStackTrace();
			}
		}
	}
}